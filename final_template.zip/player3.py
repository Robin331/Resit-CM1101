from items3 import *
from map3 import rooms

inventory = [item_pen, item_money]

# Start game at the reception
current_room = rooms["Reception"]

#Initialises the person's health at 100
current_health = 100 

#Initialises the monster's current room (this will then be randomized)
monster_room = rooms["Parking"]
