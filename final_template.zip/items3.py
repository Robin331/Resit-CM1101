item_coffee = {
    "id": "coffee",

    "name": "coffee cup",

    "mass": "0.1",

    "description":
    """Your source of energy and life"""
}

item_laptop = {
    "id": "laptop",

    "name": "laptop",

    "mass": "2",


    "description":
    "It has seen better days. At least it has a WiFi card!"
}

item_money = {
    "id": "money",

    "name": "money",

    "mass": "0.5",

    "description":
    "This wad of cash is barely enough to pay your tuition fees."
}

item_biscuits = {
    "id": "biscuits",

    "name": "a pack of biscuits",

    "mass": "0.3",

    "description": "A pack of biscuits."
}

item_pen = {
    "id": "pen",
    
    "name": "a pen",

    "mass": "0.1",

    "description": "A basic ballpoint pen."
}

item_handbook = {
    "id": "handbook",
    
    "name": "a student handbook",

    "mass": "2",

    "description": "This student handbook explains everything. Seriously."
}

item_healthpack = {
    "id": "healthpack",
    
    "name": "a healthpack",

    "mass": "0",

    "description": "This will heal your grades by 30%."
}